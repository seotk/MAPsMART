import { configureStore, createSlice } from "@reduxjs/toolkit";

let cart = createSlice({
  name: "cart",
  initialState: [],
  reducers: {
    addCount(state, action) {
      console.log("a");
      let num = state.findIndex((a) => a._id === action.payload);
      state[num].count++;
    },
    minusCount(state, action) {
      console.log("a");
      let num = state.findIndex((a) => a._id === action.payload);
      state[num].count--;
    },
    addItem(state, action) {
      const existingItemIndex = state.findIndex(
        (item) => item.title === action.payload.title
      );
      if (existingItemIndex !== -1) {
        // 이미 존재하는 아이템일 경우 count를 증가시킵니다.
        state[existingItemIndex].count += Number(action.payload.count);
      } else if (state.length < 10) {
        // 새로운 아이템을 추가합니다.
        state.push(action.payload);
      }
    },

    deleteItem(state, action) {
      let num = state.findIndex((a) => a.title === action.payload);
      console.log(action.payload);
      state.splice(num, 1);
    },
  },
});
export const { addCount, minusCount, addItem, deleteItem } = cart.actions;
export default cart;
