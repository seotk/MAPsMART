import MainBanner from "./MainBanner";
// ========================================================

import { useState, useEffect } from "react";
// ========================================================

function Main() {
  return (
    <section className="Main">
      <MainBanner />
    </section>
  );
}

export default Main;
